import React from 'react';
import { View, Text } from 'react-native';

export default function FriendsScreen() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Amigos</Text>
    </View>
  );
}
